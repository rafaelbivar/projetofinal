<?php  
    	include_once 'models/Connect.class.php';
	include_once 'models/Manager.class.php';
	session_start();

	session_destroy();

	header("location: ../index.php?msg=sessao_encerrada");

?>