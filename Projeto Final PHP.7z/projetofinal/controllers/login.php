<?php  
	
	// Adicionando os arquivos principais
	include_once dirname(__DIR__).'/models/Connect.class.php';
	include_once dirname(__DIR__).'/models/Manager.class.php';

	// Busca no banco de dados
	$manager = new Manager;
	$log = $manager->select_common("usuarios",null,array("login_usuario"=>$_POST['login'], "senha_usuario"=>$_POST['senha']), " LIMIT 1");


	if($log == false){
        header("location: ../index.php?msg=usuario_incorreto");
	}else{
   		session_start();  
      	header("location: ../admin.php");
	}
	
?>