<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Cadastro de Fornecedores </title>
	<!-- Bootstrap -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
</head>
<body>
	<div class="container">
		<div class="p-3 mb-2 bg-success text-white">
			<div class="row">
				<div class="col-3"></div>
				<div class="col-6">
					<hr><h3> Formulário de Cadastro de Fornecedores </h3><hr>
					<form action="recebef.php" method="POST">

						<label> <i class="fa fa-user"></i> Nome </label><br>
						<input type="text" class="form-control" name="nome_fornecedor" placeholder="Digite o nome"><br><br>

						<label> <i class="fa fa-address-card"></i> CNPJ </label><br>
						<input type="text" class="form-control" name="cnpj_fornecedor" placeholder="Digite o CNPJ"><br><br>
						
						<label> <i class="fa fa-industry"></i> Ramo </label><br>
						<input type="text" class="form-control" name="ramo_fornecedor" placeholder="Digite o ramo"><br><br>



						<label> <i class="fa fa-envelope"></i> Email </label><br>
						<input type="email" class="form-control" name="email_fornecedor" placeholder="Digite o email"><br><br

						<div class="row">
						<label> <i class="fa fa-globe"></i> Endereço </label><br>
						<input type="text" class="form-control" name="endereco_fornecedor" placeholder="Digite o endereço"><br><br>				
						
						<div>
							<p class="text-end">
								<button class="btn btn-outline-warning">  Enviar Dados </button>
							</p>
						</div>
					</form>	

				</div>
				<div class="col-3"></div>
			</div>
		</div>
	</div>
	<div class="p-3 mb-2 bg-warning text-dark">
		<center>
			<a href="listagemf.php"class="btn btn-primary"> Listar </a> 
			<a href="../admin.php"class="btn btn-primary"> Admin </a>  
			<a href="../controllers/logout.php"class="btn btn-primary"> SAIR </a>
		</center>
	</div>			
</body>
</html>