<?php  
	include_once dirname(__DIR__).'/models/Connect.class.php';
	include_once dirname(__DIR__).'/models/Manager.class.php';

	$manager = new Manager;
	$dados = $_POST;
	
	$manager->insert_common("vendas",$dados,null);

	echo "<script>
			  alert('Venda cadastrada');
			  window.location.href='listagemv.php';
			  </script>";

?>