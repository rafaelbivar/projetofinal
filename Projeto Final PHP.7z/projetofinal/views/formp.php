<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Cadastro de Produtos </title>
	<!-- Bootstrap -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
</head>
<body>
	<div class="container">
		<div class="p-3 mb-2 bg-success text-white">
			<div class="row">
				<div class="col-3"></div>
				<div class="col-6">
					<hr><h3> Formulário de Cadastro de Produtos </h3><hr>
					<form action="recebep.php" method="POST">

						<label>  Tipo </label><br>
						<input type="text" class="form-control" name="tipo_produto" placeholder="Digite o tipo"><br><br>

						<label> Nome </label><br>
						<input type="text" class="form-control" name="nome_produto" placeholder="Digite o nome"><br><br>

						<label> Id do Fornecedor </label><br>
						<input type="number" class="form-control" name="id_fornecedor_produto" placeholder="Digite o id do fornecedor"><br><br>

						<label>Preço de Compra </label><br>
						<input type="real" class="form-control" name="precocompra_produto" placeholder="Digite o valor de compra"><br><br>

						<label>Preço de Venda </label><br>
						<input type="real" class="form-control" name="precovenda_produto" placeholder="Digite o valor de venda"><br><br>

						<label>Quantidade em Estoque</label><br>
						<input type="real" class="form-control" name="estoque_produto" placeholder="Digite a quantidade em estoque"><br><br>
						
						<div class="col-6">
								<label> Data de validade </label><br>
								<input type="date" class="form-control" name="validade_produto"><br><br>
							</div>

						<label> Código </label><br>
						<input type="text" class="form-control" name="codigo_produto" placeholder="Digite o codigo"><br><br>						
							
														
						</div>
						<div>
							<p class="text-end">
								<button class="btn btn-outline-warning">  Enviar Dados </button>
							</p>
						</div>
					</form>	

				</div>
				<div class="col-3"></div>
			</div>
		</div>
	</div>
	<div class="p-3 mb-2 bg-warning text-dark">
		<center>
			<a href="listagemp.php"class="btn btn-primary"> Listar </a> 
			<a href="../admin.php"class="btn btn-primary"> Admin </a>  
			<a href="../controllers/logout.php"class="btn btn-primary"> SAIR </a>
		</center>
	</div>			
</body>
</html>