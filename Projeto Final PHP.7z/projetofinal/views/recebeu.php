<?php  
	include_once dirname(__DIR__).'/models/Connect.class.php';
	include_once dirname(__DIR__).'/models/Manager.class.php';

	$manager = new Manager;
	$dados = $_POST;
	
	$manager->insert_common("usuarios",$dados,null);

	echo "<script>
			  alert('Usuário cadastrado');
			  window.location.href='listagemu.php';
			  </script>";

?>