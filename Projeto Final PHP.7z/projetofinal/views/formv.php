<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Cadastro de Vendas </title>
	<!-- Bootstrap -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
</head>
<body>
	<div class="container">
		<div class="p-3 mb-2 bg-success text-white">
			<div class="row">
				<div class="col-3"></div>
				<div class="col-6">
					<hr><h3> Formulário de Cadastro de Vendas </h3><hr>
					<form action="recebev.php" method="POST">




						<div class="row">
							<div class="col-6">

								<label> Id usuário  </label><br>
								<input type="number" class="form-control" name="id_usuario_vendas" placeholder="Digite id do usuário"><br><br>
								
							</div>
							
							<div class="col-6">
								<label> Id cliente </label><br>
								<input type="number" class="form-control" name="id_cliente_vendas"placeholder="Digite id do cliente"><br><br>
							</div>							
						</div>


						<div class="row">
							<div class="col-6">

							<label> Id produto </label><br>
							<input type="number" class="form-control" name="id_produto_vendas" placeholder="Digite id do produto"><br><br>
								
							</div>
							
							<div class="col-6">
								<label> Quantidade </label><br>
								<input type="real" class="form-control" name="qt_produto_vendas" placeholder="Digite a quantidade"><br><br>
							</div>							
						</div>
						
						<div>
							<p class="text-end">
								<button class="btn btn-outline-warning">  Enviar Dados </button>
							</p>
						</div>
					</form>	

				</div>
				<div class="col-3"></div>
			</div>
		</div>
	</div>
	<div class="p-3 mb-2 bg-warning text-dark">
		<center>
			<a href="listagemv.php"class="btn btn-primary"> Listar </a> 
			<a href="../admin.php"class="btn btn-primary"> Admin </a>  
			<a href="../controllers/logout.php"class="btn btn-primary"> SAIR </a>
		</center>
	</div>			
</body>
</html>