<?php 
	include_once dirname(__DIR__).'/models/Connect.class.php';
	include_once dirname(__DIR__).'/models/Manager.class.php';

	$manager = new Manager;
	$dados = $manager->select_common("produtos",null,null, null);
	
 ?> 

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title> Listagem  </title>

		<!-- Bootstrap -->
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">

		<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">

		<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.11.0/css/jquery.dataTables.min.css">
	</head>
	<body>
		<div class="container">
			<div class="p-3 mb-2 bg-info text-white">
			<div class="row">
				<div class="col-1"></div>
				<div class="col-10">
					<hr><h3> Listagem dos Produtos </h3><hr>
					<table id="myTable" class="table table-striped table-bordered">
						<thead>
							<th> Tipo </th>
							<th> Nome </th>
							<th> Id For</th>
							<th>Preço de compra </th>
							<th>Preço de venda </th>
							<th> Estoque </th>
							<th> Validade</th>							
							<th> Código </th>
							
						</thead>
						<tbody>
							
							<?php foreach ($dados as $d): ?>
								
								<?php $cadastro =  $d; ?>
								<tr>
									<td><?=$cadastro['tipo_produto'];?></td>
									<td><?=$cadastro['nome_produto'];?></td>
									<td><?=$cadastro['id_fornecedor_produto'];?></td>
									<td><?=$cadastro['precocompra_produto'];?></td>
									<td><?=$cadastro['precovenda_produto'];?></td>
									<td><?=$cadastro['estoque_produto'];?></td>
									<td><?=$cadastro['validade_produto'];?></td>
									<td><?=$cadastro['codigo_produto'];?></td>
																		
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
				</div>
				<div class="col-1"></div>
			</div>
		</div>
		<div class="p-3 mb-2 bg-warning text-dark">
			<center>
			<a href="formp.php" class="btn btn-primary"> Cadastrar Outro </a>
			<a href="../admin.php"class="btn btn-primary"> Admin </a>
			<a href="../controllers/logout.php"class="btn btn-primary"> SAIR </a>
		
		</div>

			</center>
		</div>		
		
		<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
		<script type="text/javascript" src="//cdn.datatables.net/1.11.0/js/jquery.dataTables.min.js"></script>

		<script type="text/javascript">
			$(document).ready( function () {
			    $('#myTable').DataTable();
			});
		</script>	
	</body>
</html>

