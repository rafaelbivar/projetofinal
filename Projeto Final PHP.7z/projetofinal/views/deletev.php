<?php  
	include_once dirname(__DIR__).'/models/Connect.class.php';
	include_once dirname(__DIR__).'/models/Manager.class.php';

	$manager = new Manager;
	$dados = $_GET['id'];
	
	$manager->delete_common("vendas", array("id_vendas"=>$dados), null);

	echo "<script>
			  alert('Venda deletada');
			  window.location.href='listagemv.php';
			  </script>";

?>