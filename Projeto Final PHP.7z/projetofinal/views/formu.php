<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Cadastro de Usuário </title>
	<!-- Bootstrap -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
</head>
<body>
	<div class="container">
		<div class="p-3 mb-2 bg-success text-white">
			<div class="row">
				<div class="col-3"></div>
				<div class="col-6">
					<hr><h3> Formulário de Cadastro de Usuário </h3><hr>
					<form action="recebeu.php" method="POST">

						<label> <i class="fa fa-user"></i> Nome </label><br>
						<input type="text" class="form-control" name="nome_usuario" placeholder="Digite o nome"><br><br>
						
						<div class="col-6">

						<label> <i class="fa fa-address-card"></i> CPF </label><br>
						<input type="text" class="form-control" name="cpf_usuario" placeholder="Digite o CPF"><br><br>

							</div>

						<label> <i class="fa fa-address-card"></i> Cargo </label><br>
						<input type="text" class="form-control" name="cargo_usuario" placeholder="Digite o cargo"><br><br>

						<label> <i class="fa fa-sign-in"></i> login </label><br>
								<input type="text" class="form-control" name="login_usuario" placeholder="Digite o Login de até 10 caracteres"><br><br>

						<label> <i class="fa fa-unlock-alt"></i> Senha </label><br>
								<input type="text" class="form-control" name="senha_usuario" placeholder="Digite a Senha de até 8 caracteres"><br><br>

						<div class="row">							
							
							<div class="col-6">
								
							</div>							
						</div>
						<div>
							<p class="text-end">
								<button class="btn btn-outline-warning">  Enviar Dados </button>
							</p>
						</div>
					</form>	

				</div>
				<div class="col-3"></div>
			</div>
		</div>
	</div>
	<div class="p-3 mb-2 bg-warning text-dark">
		<center>
			<a href="listagemu.php"class="btn btn-primary"> Listar </a> 
			<a href="../admin.php"class="btn btn-primary"> Admin </a>  
			<a href="../controllers/logout.php"class="btn btn-primary"> SAIR </a>
		</center>
	</div>			
</body>
</html>