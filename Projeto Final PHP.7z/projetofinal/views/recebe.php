<?php  
	include_once dirname(__DIR__).'/models/Connect.class.php';
	include_once dirname(__DIR__).'/models/Manager.class.php';

	$manager = new Manager;
	$dados = $_POST;
	
	$manager->insert_common("clientes",$dados,null);

	echo "<script>
			  alert('Cliente cadastrado');
			  window.location.href='listagem.php';
			  </script>";

?>