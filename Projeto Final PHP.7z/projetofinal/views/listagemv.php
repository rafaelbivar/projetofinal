<?php 
	include_once dirname(__DIR__).'/models/Connect.class.php';
	include_once dirname(__DIR__).'/models/Manager.class.php';

	$manager = new Manager;
	$dados = $manager->select_common("vendas",null,null, null);

	

 ?> 

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title> Listagem das Vendas </title>

		<!-- Bootstrap -->
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">

		<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">

		<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.11.0/css/jquery.dataTables.min.css">
	</head>
	<body>
		<div class="container">
			<div class="p-3 mb-2 bg-info text-white">
			<div class="row">
				<div class="col-1"></div>
				<div class="col-10">
					<hr><h3> Listagem das Vendas </h3><hr>
					<table id="myTable" class="table table-striped table-bordered">
						<thead>
							<th> Id venda</th>
							<th> Id usuário </th>
							<th> Id cliente</th>
							<th> Id produto </th>
							<th> Quantidade</th>
							<th> Ações </th>
						</thead>
						<tbody>
							
							<?php foreach ($dados as $d): ?>
								
								<?php $cadastro =  $d; ?>
								<tr>
									<td><?=$cadastro['id_vendas'];?></td>
									<td><?=$cadastro['id_usuario_vendas'];?></td>
									<td><?=$cadastro['id_cliente_vendas'];?></td>
									<td><?=$cadastro['id_produto_vendas'];?></td>
									<td><?=$cadastro['qt_produto_vendas'];?></td>
									
									<td>
										<a href="deletev.php?id=<?=$cadastro['id_vendas'];?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
				</div>
				<div class="col-1"></div>
			</div>
		</div>
		<div class="p-3 mb-2 bg-warning text-dark">
			<center>
			<a href="formv.php" class="btn btn-primary"> Cadastrar Outra </a>
			<a href="../admin.php"class="btn btn-primary"> Admin </a>
			<a href="../controllers/logout.php"class="btn btn-primary"> SAIR </a>
		
		</div>

			</center>
		</div>		
		
		<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
		<script type="text/javascript" src="//cdn.datatables.net/1.11.0/js/jquery.dataTables.min.js"></script>

		<script type="text/javascript">
			$(document).ready( function () {
			    $('#myTable').DataTable();
			});
		</script>	
	</body>
</html>

