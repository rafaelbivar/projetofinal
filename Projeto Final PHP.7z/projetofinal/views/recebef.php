<?php  
	include_once dirname(__DIR__).'/models/Connect.class.php';
	include_once dirname(__DIR__).'/models/Manager.class.php';

	$manager = new Manager;
	$dados = $_POST;
	
	$manager->insert_common("fornecedores",$dados,null);

	echo "<script>
			  alert('fornecedor cadastrado');
			  window.location.href='listagemf.php';
			  </script>";

?>